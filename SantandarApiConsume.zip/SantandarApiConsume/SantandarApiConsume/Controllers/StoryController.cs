﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SantandarApiConsume.Models;
using SantandarApiConsume.Repository.IRepository;
using System.Net.Http.Headers;

namespace SantandarApiConsume.Controllers
{
    //[ApiController]
    //[Route("api/[controller]")]
    public class StoryController : Controller
    {
        private readonly IStoryService _storyApiService;

        public StoryController(IStoryService storyApiService)
        {
            _storyApiService = storyApiService;
        }
        [HttpGet]
        public IActionResult Index()
        {
           
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Index(int Id)
        {
            StoryDetails story = new StoryDetails();

            if (Id > 0)
            {
                story = await _storyApiService.GetStoryDetails(Id);
            }
            return View(story);
        }

        public IActionResult bestStories()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> bestStories(int No)
        {
            List<StoryDetails> story = new List<StoryDetails>();

            story = await _storyApiService.bestStories(No);

            return View(story);
        }

      
    }
}
