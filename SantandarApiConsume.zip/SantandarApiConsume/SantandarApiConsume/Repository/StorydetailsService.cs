﻿using Microsoft.AspNetCore.Mvc;
using SantandarApiConsume.Models;
using SantandarApiConsume.Repository.IRepository;
using System.Configuration;
using System.Net.Http;
using System.Text.Json;

namespace SantandarApiConsume.Repository
{
    public class StorydetailsService : IStoryService
    {
        private  readonly HttpClient client;
        private readonly IHttpClientFactory _httpClientFactory;
        private IConfiguration _configuration;
        public StorydetailsService(IHttpClientFactory clientFactory, IHttpClientFactory httpClientFactory,IConfiguration configuration)
        {
            client = clientFactory.CreateClient("PublicStoryApi");
            _httpClientFactory = httpClientFactory;
            _configuration= configuration;

        }

        public async Task<StoryDetails> GetStoryDetails(int Id)
        {
            var url = string.Format("item/{0}.json", Id);
            var result = new StoryDetails();
            var response = await client.GetAsync(url);
            if (response.IsSuccessStatusCode)
            {
                var stringResponse = await response.Content.ReadAsStringAsync();

                result = JsonSerializer.Deserialize<StoryDetails>(stringResponse,
                    new JsonSerializerOptions() { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });
            }
            else
            {
                throw new HttpRequestException(response.ReasonPhrase);
            }

            return result;
        }
        public async Task<List<StoryDetails>> bestStories(int No)
        {
            var bestStoryIds = await GetBestStoryIdsAsync(No);

            // Initialize the list of best stories as an empty list
            var bestStories = new List<StoryDetails>();

            // Retrieve story details for each ID and add them to the list
            foreach (var storyId in bestStoryIds)
            {
                var story = await GetStoryDetailsAsync(storyId);
                if (story != null)
                {
                    bestStories.Add(story);
                }
            }

            // Sort stories by score in descending order
            bestStories = bestStories.OrderByDescending(s => s.score).ToList();

            return bestStories;
        }
        private async Task<IEnumerable<int>> GetBestStoryIdsAsync(int n)
        {
            // Make an HTTP request to get the best story IDs
            var client = _httpClientFactory.CreateClient();
            string beststories = _configuration.GetValue<string>("MySettings:beststories");
                        var response = await client.GetFromJsonAsync<int[]>(beststories);

            // Take the first 'n' story IDs
            return response.Take(n);
        }


        private async Task<StoryDetails> GetStoryDetailsAsync(int storyId)
        {
            var client = _httpClientFactory.CreateClient();
            string storyById = _configuration.GetValue<string>("MySettings:storyId");

            var storyResponse = await client.GetFromJsonAsync<StoryDetails>($"{storyById}{storyId}.json");

            return storyResponse;
        }
    }
}