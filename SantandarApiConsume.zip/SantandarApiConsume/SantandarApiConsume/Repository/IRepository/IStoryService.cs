﻿using SantandarApiConsume.Models;

namespace SantandarApiConsume.Repository.IRepository
{


    public interface IStoryService
    {
        Task<StoryDetails> GetStoryDetails(int Id);
        Task<List<StoryDetails>> bestStories(int No);
    }
}
